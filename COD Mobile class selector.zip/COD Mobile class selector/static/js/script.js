const weaponDataBase = {
    'primary': {
        'map': ['assault-rifles','sub-machine-guns','light-machine-guns','shotguns','sniper-rifles'],

        'assault-rifles': ['ak-47','ak117','asm10','bk57','dr-h','hbra3','hvk-30','icr-1','kn-44','lk24','m4','m16','mow','type25'],

        'sub-machine-guns': ['agr-556','chicom','cordite','fennec','gks','hg40','msmc','pdw-57','pharo','qq9','razorback','rus-79u'],

        'light-machine-guns': ['chopper','m4lmg','rpd','s36','ul736'],

        'shotguns': ['by15','echo','hs0405','hs2126','striker'],

        'sniper-rifles': ['artic-50','dlq33','kilo','locus','m21-ebr','na-45','outlaw','xpr-50']
        },

    'secondary': {
        'map': ['pistols','melee','launchers'],

        'pistols': ['j358','mw11','.50-gs'],

        'melee': ['axe','bat','knife'],

        'launchers': ['fhj-18','smrs'],
    },
}

const equipmentDataBase = {

    'map': ['lethal','tactical','operator','perk1','perk2','perk3'],

    'lethal': ['frag','molotov','sentex','sentex','trip-mine'],

    'tactical': ['concussion-grenade','emp','flash-bang','smoke-grenade','trophy-system'],

    'operator': ['annihilator','ballistic-shield','death-machine','equalizer','gravity-spikes','hive','katana','purifier','sparrow','tempest','transform-shield','war-machine'],

    'perk1': ['agile','fast-recover','flak-jacket','light-weight','persistance','skulker'],

    'perk2': ['amped','cold-blooded','ghost','hard-wired','quick-fix','toughness','tracker','vulture'],

    'perk3': ['alert','dead-silence','demo-expert','engineer','hardline','high-alert','shrapnel','tactical-mask'],
};
    //'pickerMap': ['primary','secondary','lethal','tactical','operator','perk1','perk2','perk3'],

document.getElementById('generate').addEventListener('click', generateClass);

let primarySRC = [], secondarySRC = []; equipmentSRC = []; fullSRC = []
let equipment = ['lethal','tactical','operator','perk1','perk2','perk3'];

function generateClass() {
    primarySRC = []; secondarySRC = []; equipmentSRC = []; fullSRC = [];
    //removes existing images
    removeImage();
    CategoryPicker();
    primaryGunPicker(gunPick[0]);
    secondaryGunPicker(gunPick[1]);
    equipmentPicker();
    console.log(primarySRC);
    console.log(secondarySRC);
    console.log(equipmentSRC);
    fullSRC = fullSRC.concat(primarySRC,secondarySRC,equipmentSRC); 
    console.log(fullSRC);

    CreateClass();
   
};

function CategoryPicker() {
    //collects a random object name in primary

    let primaryIndex = Math.floor(Math.random() * weaponDataBase['primary'].map.length);

    let secondaryIndex = Math.floor(Math.random() * weaponDataBase['secondary'].map.length);
    
    gunPick = [primaryPick= weaponDataBase['primary'].map[primaryIndex],secondaryPick = weaponDataBase['secondary'].map[secondaryIndex]]; 
    // gunPick will pick a category within primary and secondary.
    return gunPick;
};

function primaryGunPicker(category) {
    // Picks a random weapon within the category Ex: Category - Assault Rifle, picks a random assault rifle.
    let primaryGunIndex = Math.floor(Math.random() * weaponDataBase['primary'][category].length);

    // this is the source we will use to add an image to html, it fetches the category from gunPick and the weapon from the random formula above.
    primarySRC.push(`static/images/primary/${category}/${weaponDataBase['primary'][category][primaryGunIndex]}.jpg`);
};

function secondaryGunPicker(category) {
    // Picks a random weapon within the category Ex: Category - Melee, picks a random melee weapon.
    let secondaryGunIndex = Math.floor(Math.random() * weaponDataBase['secondary'][category].length);

    secondarySRC.push(`static/images/secondary/${category}/${weaponDataBase['secondary'][category][secondaryGunIndex]}.jpg`);
};

function equipmentPicker() {
// for each equipment category it picks a random item and gives us the source so we can add it to our html page
    for (i=0; i < equipment.length; i++) {
        let equipmentIndex = Math.floor(Math.random() * equipmentDataBase[equipment[i]].length);
        
        equipmentSRC.push(`static/images/${equipment[i]}/${equipmentDataBase[equipment[i]][equipmentIndex]}.jpg`);
    };
    
};

function CreateClass() {

    let names = ['primary','secondary','lethal','tactical','operator','perk1','perk2','perk3'];

    for (i = 0; i < names.length; i++) {
        let image = document.createElement('img');
        image.src = fullSRC[i];
        document.querySelector(`#${names[i]}Div`).appendChild(image);
    };    
};

function removeImage() {
    let images = new Array;
    images = document.querySelector(`.class-container`).querySelectorAll('img');
    console.log(images);

    if (images.length > 1) {
        for(i=0; i < images.length; i++) {
            images[i].remove();
        }; 
    };
};